
import mongoose from 'mongoose';
import dotenv from 'dotenv';

dotenv.config();

const connectDB = async () => {
  try {
    // Use the provided Atlas URI or fallback to env
    const uri = process.env.MONGO_URI || "mongodb+srv://hafizUser:Hafiz2025Strong!@arraqamiydb.sb9ozwg.mongodb.net/ArRaqamiyDB?retryWrites=true&w=majority&appName=ArRaqamiyDB";
    
    const conn = await mongoose.connect(uri);
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
};

export default connectDB;
