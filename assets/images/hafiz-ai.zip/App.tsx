
import React, { useState, useEffect, useMemo } from 'react';
import { 
  Search, Layout, Menu, X, Bell, User as UserIcon, 
  CalendarDays, Volume2, ShieldAlert, Sparkles,
  BookOpen, Mic, MicOff, BarChart3, Settings2
} from 'lucide-react';
import { quranApi } from './services/quran';
import { db } from './services/db';
import { Surah, AppMode, HifzPlanJSON, DailyTask, Language } from './types';
import Dashboard from './components/Dashboard';
import Learning from './components/Learning';
import HifzPlanning from './components/HifzPlanning';
import LandingPage from './components/LandingPage';
import Testing from './components/Testing';
import AnalysisView from './components/AnalysisView';

const App: React.FC = () => {
  const [showLanding, setShowLanding] = useState(true);
  const [activeMode, setActiveMode] = useState<AppMode>(AppMode.ADMIN); 
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [selectedSurah, setSelectedSurah] = useState<Surah | null>(null);
  const [currentAyahIdx, setCurrentAyahIdx] = useState(0);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false); 
  const [searchQuery, setSearchQuery] = useState('');
  const [user, setUser] = useState<any>(null);
  const [activePlan, setActivePlan] = useState<HifzPlanJSON | null>(null);
  const [persistentNotification, setPersistentNotification] = useState<{ title: string, body: string } | null>(null);
  
  // Ovozli boshqaruv holati (Global boshqaruv uchun)
  const [isVoiceMode, setIsVoiceMode] = useState(false);

  useEffect(() => {
    const init = async () => {
      const data = await quranApi.getSurahs();
      setSurahs(data);
      const localUser = db.getUser();
      setUser(localUser);
      const plan = localStorage.getItem('active_hifz_plan');
      if (plan) setActivePlan(JSON.parse(plan));
    };
    init();
  }, [activeMode]);

  useEffect(() => {
    if (activePlan && activePlan.dailyTasks) {
      const checkReminder = () => {
        const now = new Date();
        const currentTimeStr = now.getHours().toString().padStart(2, '0') + ":" + now.getMinutes().toString().padStart(2, '0');
        const todayStr = now.toISOString().split('T')[0];
        const todayTask = activePlan.dailyTasks.find(t => t.date === todayStr);

        if (currentTimeStr === activePlan.morningReminder) {
          if (todayTask) {
            setPersistentNotification({
              title: "Bugungi Vazifa",
              body: `Assalomu alaykum! Bugun ${todayTask.surahName} surasi ${todayTask.startAyah}-${todayTask.endAyah}-oyatlarni yodlashingiz kerak.`
            });
          }
        } else if (currentTimeStr === activePlan.eveningReminder) {
          setPersistentNotification({
            title: "Kechki Rahmatnoma",
            body: `Kun yakunlandi! Bugungi natijangiz uchun rahmat. Iltimos, hisobotingizni tasdiqlang.`
          });
        }
      };
      const interval = setInterval(checkReminder, 60000);
      return () => clearInterval(interval);
    }
  }, [activePlan]);

  const handleSelectSurah = (surah: Surah) => {
    setSelectedSurah(surah);
    setCurrentAyahIdx(0);
    setActiveMode(AppMode.TEACHING);
    setIsSidebarOpen(false);
  };

  const handlePlanSave = (plan: HifzPlanJSON) => {
    setActivePlan(plan);
    localStorage.setItem('active_hifz_plan', JSON.stringify(plan));
    setActiveMode(AppMode.ADMIN);
  };

  if (showLanding) return <LandingPage onStart={() => setShowLanding(false)} />;

  return (
    <div className="flex h-screen bg-white overflow-hidden font-sans text-slate-900">
      {persistentNotification && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-xl animate-in fade-in zoom-in duration-500">
           <div className="bg-white w-full max-w-lg rounded-[3.5rem] p-12 shadow-2xl border-b-8 border-emerald-500 animate-bounce-short relative overflow-hidden">
              <div className="flex flex-col items-center text-center gap-8 relative z-10">
                 <div className="w-24 h-24 bg-emerald-50 rounded-3xl flex items-center justify-center text-emerald-600 ring-8 ring-emerald-50/50">
                    <Bell size={48} className="animate-ring" />
                 </div>
                 <div className="space-y-3">
                    <h3 className="text-3xl font-black text-slate-900 tracking-tight">{persistentNotification.title}</h3>
                    <p className="text-lg text-slate-500 font-bold leading-relaxed">{persistentNotification.body}</p>
                 </div>
                 <button onClick={() => setPersistentNotification(null)} className="w-full py-5 bg-emerald-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl">Yopish</button>
              </div>
           </div>
        </div>
      )}

      <aside className={`fixed lg:static inset-y-0 left-0 z-[100] w-72 bg-white border-r border-slate-100 transition-all duration-300 transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 flex flex-col shadow-sm`}>
        <div className="h-16 px-6 border-b border-slate-50 flex items-center justify-between">
           <div className="flex items-center gap-3 cursor-pointer" onClick={() => {setActiveMode(AppMode.ADMIN); setSelectedSurah(null);}}>
              <div className="w-9 h-9 bg-emerald-600 rounded-xl flex items-center justify-center text-white shadow-lg"><span className="font-serif font-black text-lg">H</span></div>
              <h1 className="font-black text-slate-800 tracking-tight text-base">Hafiz AI</h1>
           </div>
           <button onClick={() => setIsSidebarOpen(false)} className="lg:hidden p-2 text-slate-400"><X size={20}/></button>
        </div>
        <nav className="flex-1 overflow-y-auto p-4 space-y-1.5 custom-scrollbar">
           <button onClick={() => {setActiveMode(AppMode.ADMIN); setSelectedSurah(null);}} className={`w-full flex items-center gap-3 p-3.5 rounded-xl transition-all ${activeMode === AppMode.ADMIN && !selectedSurah ? 'bg-slate-900 text-white' : 'hover:bg-slate-50 text-slate-500'}`}>
             <Layout size={18} /> <span className="text-[10px] font-black uppercase tracking-widest">Dashboard</span>
           </button>
           <button onClick={() => {setActiveMode(AppMode.HIFZ_PLAN); setSelectedSurah(null);}} className={`w-full flex items-center gap-3 p-3.5 rounded-xl transition-all ${activeMode === AppMode.HIFZ_PLAN ? 'bg-emerald-600 text-white shadow-lg' : 'hover:bg-slate-50 text-slate-500'}`}>
             <CalendarDays size={18} /> <span className="text-[10px] font-black uppercase tracking-widest">Hifz Rejasi</span>
           </button>
           <div className="pt-6 pb-2">
              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-4 mb-3">Suralar</p>
              <div className="space-y-1">
                {surahs.filter(s => s.englishName.toLowerCase().includes(searchQuery.toLowerCase())).slice(0, 15).map(s => (
                  <button key={s.number} onClick={() => handleSelectSurah(s)} className={`w-full flex items-center gap-3 p-2.5 rounded-xl transition-all ${selectedSurah?.number === s.number ? 'bg-emerald-50 text-emerald-700' : 'hover:bg-slate-50 text-slate-500'}`}>
                    <span className="text-[8px] font-black w-5 h-5 rounded bg-white border border-slate-100 flex items-center justify-center">{s.number}</span>
                    <p className="text-[10px] font-black uppercase truncate">{s.englishName}</p>
                  </button>
                ))}
              </div>
           </div>
        </nav>
      </aside>

      <main className="flex-1 flex flex-col relative bg-slate-50/20 overflow-hidden">
        <header className="h-16 bg-white/80 backdrop-blur-md border-b border-slate-100 flex items-center justify-between px-8 z-50 sticky top-0">
          <div className="flex items-center gap-6">
            <button onClick={() => setIsSidebarOpen(true)} className="lg:hidden p-2 text-slate-900 bg-slate-100 rounded-lg"><Menu size={18} /></button>
            <h2 className="text-xs font-black text-slate-900 uppercase tracking-[0.2em]">
              {selectedSurah ? selectedSurah.englishName : 'Hafiz AI'}
            </h2>
          </div>

          {selectedSurah && (
            <div className="flex items-center bg-slate-100/50 p-1 rounded-2xl border border-slate-100">
              <button onClick={() => setActiveMode(AppMode.TEACHING)} className={`px-6 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${activeMode === AppMode.TEACHING ? 'bg-white text-emerald-600 shadow-sm border border-slate-100' : 'text-slate-400 hover:text-slate-600'}`}>Yodlash</button>
              <button onClick={() => setActiveMode(AppMode.TESTING)} className={`px-6 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${activeMode === AppMode.TESTING ? 'bg-white text-emerald-600 shadow-sm border border-slate-100' : 'text-slate-400 hover:text-slate-600'}`}>Sinov</button>
              <button onClick={() => setActiveMode(AppMode.ANALYSIS)} className={`px-6 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${activeMode === AppMode.ANALYSIS ? 'bg-white text-emerald-600 shadow-sm border border-slate-100' : 'text-slate-400 hover:text-slate-600'}`}>Tahlil</button>
            </div>
          )}
          
          <div className="flex items-center gap-4">
            {selectedSurah && (
              <button 
                onClick={() => setIsVoiceMode(!isVoiceMode)}
                className={`flex items-center gap-2 px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${isVoiceMode ? 'bg-emerald-600 text-white shadow-lg' : 'bg-white border border-slate-200 text-slate-400 hover:text-slate-600'}`}
              >
                {isVoiceMode ? <Mic size={14} className="animate-pulse" /> : <MicOff size={14} />}
                <span className="hidden md:inline">Ovozli Boshqaruv</span>
              </button>
            )}
            
            <button className="relative w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center font-black text-xs shadow-lg hover:scale-105 transition-transform">
              {user?.name?.[0] || 'JD'}
              {persistentNotification && <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 border-2 border-white rounded-full animate-pulse" />}
            </button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto">
           {activeMode === AppMode.ADMIN && !selectedSurah && <Dashboard onSelectSurah={handleSelectSurah} onStartPlanning={() => setActiveMode(AppMode.HIFZ_PLAN)} />}
           {activeMode === AppMode.HIFZ_PLAN && <HifzPlanning onPlanSaved={handlePlanSave} />}
           {selectedSurah && activeMode === AppMode.TEACHING && <Learning surah={selectedSurah} currentIdx={currentAyahIdx} onAyahChange={setCurrentAyahIdx} onSurahChange={() => {}} onModeChange={setActiveMode} sidebarOpen={isSidebarOpen} voiceModeProp={isVoiceMode} />}
           {selectedSurah && activeMode === AppMode.TESTING && <Testing surah={selectedSurah} onModeChange={setActiveMode} />}
           {selectedSurah && activeMode === AppMode.ANALYSIS && <AnalysisView language={Language.UZ} onGoToAyah={(s, a) => setCurrentAyahIdx(a)} />}
        </div>
      </main>
      <style>{`@keyframes ring { 0% { transform: rotate(0); } 5% { transform: rotate(15deg); } 10% { transform: rotate(-15deg); } 15% { transform: rotate(10deg); } 20% { transform: rotate(-10deg); } 25% { transform: rotate(0); } 100% { transform: rotate(0); } } .animate-ring { animation: ring 1s ease infinite; } .animate-bounce-short { animation: bounce-short 2s infinite; } @keyframes bounce-short { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }`}</style>
    </div>
  );
};

export default App;
