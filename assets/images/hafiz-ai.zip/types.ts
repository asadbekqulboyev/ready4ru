
export enum AppMode {
  TEACHING = 'teaching',
  TESTING = 'testing',
  ANALYSIS = 'analysis',
  ADMIN = 'admin',
  USTOZ_PANEL = 'ustoz_panel',
  USTOZ_CHAT = 'ustoz_chat',
  HIFZ_PLAN = 'hifz_plan',
  TAJWEED_RULES = 'tajweed_rules'
}

export enum Language {
  UZ = 'uz',
  EN = 'en'
}

export interface Surah {
  number: number;
  name: string;
  englishName: string;
  englishNameTranslation: string;
  numberOfAyahs: number;
  revelationType: string;
}

export interface Word {
  id: number;
  text: string;
  position: number;
}

export interface Ayah {
  number: number;
  source?: string;
  text: string;
  numberInSurah: number;
  translation: string;
  ayahKey: string;
  audioUrl: string;
  words?: Word[];
}

export interface DailyTask {
  day: number;
  surahName: string;
  surahNumber: number;
  startAyah: number;
  endAyah: number;
  isCompleted: boolean;
  date?: string;
}

export interface HifzPlanJSON {
  strategy: 'whole' | 'custom';
  selectedSurahs: number[];
  startDate: string;
  endDate: string;
  morningReminder: string;
  eveningReminder: string;
  totalAyahs: number;
  dailyTasks: DailyTask[];
  notificationMethods: ('sms' | 'telegram' | 'email' | 'push')[];
}

export interface User {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  telegramId?: string;
  avatar?: string;
  role: 'student' | 'ustoz' | 'admin';
  authMethod: 'google' | 'phone' | 'telegram';
}

// Added missing interface used in services/db.ts
export interface HifzProgress {
  surahNumber: number;
  ayahNumber: number;
  status: 'new' | 'learning' | 'review' | 'mastered';
  lastReviewed: string;
}

// Added missing interface used in services/quranApi.ts
export interface Edition {
  identifier: string;
  name: string;
  englishName: string;
  language: string;
  format: string;
  type: string;
}

// Added missing interface used in services/quranService.ts
export interface CombinedAyahData {
  number: number;
  numberInSurah: number;
  text: string;
  tajweed: string;
  translation: string;
  audioUrl: string;
  tafsir: string;
}
