
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  Play, Pause, ChevronLeft, ChevronRight, 
  User, Check, Gauge, Volume2, RefreshCw, ChevronDown, AlertCircle, Loader2, Mic, MicOff, Settings2, Waves, ListMusic
} from 'lucide-react';
import { Surah, Ayah, AppMode } from '../types';
import { quranApi, RECITERS } from '../services/quran';
import { parseTajweed, splitTajweedToWords, isAyahMarker } from '../utils/tajweedParser';

interface LearningProps {
  surah: Surah;
  currentIdx: number;
  onAyahChange: (idx: number) => void;
  onSurahChange: (direction: 'next' | 'prev') => void;
  onModeChange: (mode: AppMode) => void;
  sidebarOpen: boolean;
  voiceModeProp?: boolean;
}

interface IWindow extends Window {
  webkitSpeechRecognition: any;
  SpeechRecognition: any;
}

const Learning: React.FC<LearningProps> = ({ surah, currentIdx, onAyahChange, onSurahChange, voiceModeProp = false }) => {
  const [ayahs, setAyahs] = useState<any[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [loading, setLoading] = useState(true);
  const [isAudioUpdating, setIsAudioUpdating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [selectedReciter, setSelectedReciter] = useState(7);
  const [playbackRate, setPlaybackRate] = useState(1.0);
  const [isReciterMenuOpen, setIsReciterMenuOpen] = useState(false);
  const [isSpeedMenuOpen, setIsSpeedMenuOpen] = useState(false);
  const [activeWordIdx, setActiveWordIdx] = useState<number | null>(null);
  const [audioError, setAudioError] = useState(false);
  
  // VOICE CONTROL STATES
  const [isListening, setIsListening] = useState(false);
  const [lastDetectedCommand, setLastDetectedCommand] = useState<string>('');
  const [interimTranscript, setInterimTranscript] = useState<string>('');
  
  const [isProcessingVoice, setIsProcessingVoice] = useState(true);
  const isAutoPlayingAllRef = useRef(false);
  const processingRef = useRef(true); 
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    processingRef.current = isProcessingVoice;
  }, [isProcessingVoice]);

  useEffect(() => {
    const fetchAyahs = async () => {
      const isSurahChange = ayahs.length === 0 || ayahs[0]?.ayahKey?.split(':')[0] !== surah.number.toString();
      if (isSurahChange) setLoading(true);
      else setIsAudioUpdating(true);

      try {
        const data = await quranApi.getSurahData(surah.number, selectedReciter);
        setAyahs(data);
      } catch (err) {
        setAudioError(true);
      } finally {
        setLoading(false);
        setIsAudioUpdating(false);
      }
    };
    fetchAyahs();
  }, [surah.number, selectedReciter]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      audioRef.current.playbackRate = playbackRate;
      setIsPlaying(false);
      setProgress(0);
      setActiveWordIdx(null);
    }
  }, [currentIdx, playbackRate, surah.number]);

  useEffect(() => {
    if (!voiceModeProp) {
      if (recognitionRef.current) {
        recognitionRef.current.onend = null;
        recognitionRef.current.stop();
        recognitionRef.current = null;
      }
      setIsListening(false);
      return;
    }

    const initRecognition = () => {
      const { webkitSpeechRecognition, SpeechRecognition } = window as unknown as IWindow;
      const Recognition = SpeechRecognition || webkitSpeechRecognition;
      if (!Recognition) return;

      const recognition = new Recognition();
      recognition.lang = 'uz-UZ';
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => {
        if (voiceModeProp && recognitionRef.current) {
          try { recognition.start(); } catch (e) { setTimeout(() => { if (voiceModeProp) recognition.start(); }, 100); }
        } else { setIsListening(false); }
      };

      recognition.onresult = (event: any) => {
        if (!processingRef.current) return;
        let currentInterim = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const transcript = event.results[i][0].transcript.toLowerCase().trim();
          if (event.results[i].isFinal) {
            setInterimTranscript('');
            handleCommandProcessing(transcript);
          } else {
            currentInterim = transcript;
            if (processingRef.current && isInstantCommand(currentInterim)) handleCommandProcessing(currentInterim);
          }
        }
        setInterimTranscript(currentInterim);
      };

      recognitionRef.current = recognition;
      try { recognition.start(); } catch (e) {}
    };

    initRecognition();
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.onend = null;
        recognitionRef.current.stop();
        recognitionRef.current = null;
      }
    };
  }, [voiceModeProp]);

  const isInstantCommand = (text: string) => {
    const instantTriggers = ["boshla", "to'xtat", "stop", "ijro", "pauza", "keyingi", "oldingi", "o'qi", "surani o'qi", "to'liq o'qi"];
    return instantTriggers.some(t => text.endsWith(t) || text === t);
  };

  const handleCommandProcessing = (cmd: string) => {
    const COMMAND_DICT = {
      PLAY_ALL: [/to'liq o'qi/, /hammasini o'qi/, /surani o'qi/],
      PLAY_SINGLE: [/boshla/, /ijro/, /o'qi/, /play/],
      PAUSE: [/to'xtat/, /pauza/, /stop/],
      NEXT_AYAH: [/keyingi oyat/, /keyingi/],
      PREV_AYAH: [/oldingi oyat/, /oldingi/]
    };
    let matched = false;
    if (COMMAND_DICT.PLAY_ALL.some(p => p.test(cmd))) {
      matched = true; isAutoPlayingAllRef.current = true; setIsProcessingVoice(false); startPlayback();
    } else if (COMMAND_DICT.PLAY_SINGLE.some(p => p.test(cmd))) {
      matched = true; isAutoPlayingAllRef.current = false; setIsProcessingVoice(false); startPlayback();
    } else if (COMMAND_DICT.PAUSE.some(p => p.test(cmd))) {
      matched = true; pausePlayback();
    } else if (COMMAND_DICT.NEXT_AYAH.some(p => p.test(cmd))) {
      matched = true; handleNextAyah();
    } else if (COMMAND_DICT.PREV_AYAH.some(p => p.test(cmd))) {
      matched = true; handlePrevAyah();
    }
    if (matched) {
      setLastDetectedCommand(cmd);
      setInterimTranscript('');
      setTimeout(() => setLastDetectedCommand(''), 3000);
    }
  };

  const startPlayback = () => {
    if (!audioRef.current || !currentAyah?.audioUrl) return;
    setAudioError(false);
    audioRef.current.play().then(() => setIsPlaying(true)).catch(() => { setAudioError(true); setIsProcessingVoice(true); });
  };

  const pausePlayback = () => {
    if (!audioRef.current) return;
    audioRef.current.pause();
    setIsPlaying(false);
    setIsProcessingVoice(true); 
    isAutoPlayingAllRef.current = false;
  };

  const togglePlay = () => {
    if (isPlaying) pausePlayback();
    else { isAutoPlayingAllRef.current = false; setIsProcessingVoice(false); startPlayback(); }
  };

  const handleNextAyah = () => { if (currentIdx < ayahs.length - 1) onAyahChange(currentIdx + 1); };
  const handlePrevAyah = () => { if (currentIdx > 0) onAyahChange(currentIdx - 1); };
  const handleEnded = () => {
    setIsPlaying(false);
    if (isAutoPlayingAllRef.current && currentIdx < ayahs.length - 1) onAyahChange(currentIdx + 1);
    else { setIsProcessingVoice(true); isAutoPlayingAllRef.current = false; }
  };

  useEffect(() => {
    if (isAutoPlayingAllRef.current && !isPlaying && !loading && currentAyah?.audioUrl) {
      const playTimeout = setTimeout(() => startPlayback(), 50);
      return () => clearTimeout(playTimeout);
    }
  }, [currentIdx, loading]);

  const handleTimeUpdate = () => {
    if (audioRef.current && audioRef.current.duration) {
      const currentTime = audioRef.current.currentTime;
      const duration = audioRef.current.duration;
      setProgress((currentTime / duration) * 100);
      if (wordsOnly.length > 0) {
        const estimatedWordIdx = Math.floor((currentTime / duration) * wordsOnly.length);
        setActiveWordIdx(estimatedWordIdx < wordsOnly.length ? estimatedWordIdx : wordsOnly.length - 1);
      }
    }
  };

  const currentAyah = ayahs[currentIdx];
  const reciter = RECITERS.find(r => r.id === selectedReciter);
  const { wordsOnly, ayahMarker } = useMemo(() => {
    if (!currentAyah?.text) return { wordsOnly: [], ayahMarker: null };
    const allPieces = splitTajweedToWords(currentAyah.text);
    const lastPiece = allPieces[allPieces.length - 1];
    if (isAyahMarker(lastPiece)) return { wordsOnly: allPieces.slice(0, -1), ayahMarker: lastPiece };
    return { wordsOnly: allPieces, ayahMarker: null };
  }, [currentAyah]);

  return (
    <div className="h-full flex flex-col bg-white relative">
      {/* Voice Status Indicator Floating */}
      {voiceModeProp && (
        <div className="absolute top-6 left-1/2 -translate-x-1/2 z-[60] flex items-center gap-3 px-4 py-2 bg-emerald-50 border border-emerald-100 rounded-full shadow-sm animate-in fade-in slide-in-from-top-4 duration-500">
           <div className={`w-2 h-2 rounded-full bg-emerald-500 ${isListening ? 'animate-ping' : ''}`} />
           <span className="text-[10px] font-black text-emerald-700 uppercase tracking-widest">
             {interimTranscript ? `"${interimTranscript}"` : isProcessingVoice ? 'Buyruq kutilyapti...' : 'Oyat o\'qilmoqda'}
           </span>
        </div>
      )}

      {/* FLOATING COMMAND NOTIFICATION */}
      {lastDetectedCommand && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 z-[120] w-full max-w-sm px-6 pointer-events-none">
           <div className="bg-white/95 backdrop-blur-xl border-2 border-emerald-500 px-6 py-4 rounded-3xl shadow-2xl flex flex-col items-center gap-2 animate-bounce-short">
              <span className="text-[10px] font-black uppercase tracking-widest text-emerald-600">Bajarildi</span>
              <p className="text-xl font-black text-emerald-700 capitalize">{lastDetectedCommand}</p>
           </div>
        </div>
      )}

      <div className="flex-1 flex flex-col items-center justify-start p-6 md:p-12 overflow-y-auto custom-scrollbar">
        <div className="w-full max-w-5xl py-8 md:py-16">
          {loading ? (
            <div className="flex flex-col items-center justify-center space-y-6 pt-20">
               <Loader2 className="w-10 h-10 text-emerald-500 animate-spin" />
               <p className="text-slate-400 font-bold uppercase tracking-widest text-[9px]">Yuklanmoqda...</p>
            </div>
          ) : currentAyah ? (
            <div className="space-y-12 animate-slide-up text-center">
              <div className="quran-text text-5xl md:text-6xl lg:text-7xl text-slate-800 select-none text-center" dir="rtl" lang="ar">
                {wordsOnly.map((word, idx) => (
                  <span key={idx} className={`quran-word ${activeWordIdx === idx ? 'active' : ''}`} dangerouslySetInnerHTML={{ __html: parseTajweed(word) }} />
                ))}
                {ayahMarker && (
                  <span className="ayah-marker-wrapper">
                    <span className="ayah-marker-seal" dangerouslySetInnerHTML={{ __html: parseTajweed(ayahMarker) }} />
                  </span>
                )}
              </div>
              <div className="space-y-8">
                <p className="text-xl md:text-2xl text-slate-400 font-medium leading-relaxed max-w-3xl mx-auto italic">{currentAyah.translation}</p>
                {audioError && <div className="text-red-500 text-xs font-bold">Audio xatolik</div>}
              </div>
            </div>
          ) : null}
        </div>
      </div>

      <div className="fixed bottom-0 right-0 left-0 lg:left-72 bg-white border-t border-slate-100 z-[100] shadow-[0_-10px_40px_rgba(0,0,0,0.05)]">
        <div className="w-full h-1 bg-slate-50 cursor-pointer overflow-hidden relative group" 
             onClick={(e) => {
               if (!audioRef.current?.duration) return;
               const rect = e.currentTarget.getBoundingClientRect();
               audioRef.current.currentTime = ((e.clientX - rect.left) / rect.width) * audioRef.current.duration;
             }}>
          <div className="h-full bg-emerald-500 transition-all duration-200" style={{ width: `${progress}%` }} />
        </div>
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex-1">
             <button onClick={() => setIsReciterMenuOpen(!isReciterMenuOpen)} className="flex items-center gap-3 px-4 py-2 bg-slate-50 hover:bg-slate-100 rounded-xl text-slate-600 font-black text-[10px] uppercase tracking-tighter">
                <User size={12} /> <span>{reciter?.name.split(' ').pop()}</span>
             </button>
             {isReciterMenuOpen && (
                <div className="absolute bottom-full left-6 mb-4 w-56 bg-white rounded-2xl shadow-2xl border p-2 flex flex-col z-[110]">
                   {RECITERS.map(r => (
                     <button key={r.id} onClick={() => {setSelectedReciter(r.id); setIsReciterMenuOpen(false);}} className={`text-left p-2.5 hover:bg-slate-50 rounded-lg text-[11px] font-bold ${selectedReciter === r.id ? 'text-emerald-600 bg-emerald-50' : 'text-slate-600'}`}>{r.name}</button>
                   ))}
                </div>
             )}
          </div>
          <div className="flex items-center gap-8">
            <button disabled={currentIdx === 0} onClick={handlePrevAyah} className="text-slate-300 hover:text-emerald-600 disabled:opacity-10 transition-all hover:scale-110"><ChevronLeft size={32}/></button>
            <button onClick={togglePlay} className="w-14 h-14 bg-slate-900 text-white rounded-2xl flex items-center justify-center shadow-xl hover:bg-emerald-600 transition-all active:scale-95">
               {isPlaying ? <Pause size={28} fill="currentColor" /> : <Play size={28} fill="currentColor" className="ml-1" />}
            </button>
            <button disabled={currentIdx === ayahs.length - 1} onClick={handleNextAyah} className="text-slate-300 hover:text-emerald-600 disabled:opacity-10 transition-all hover:scale-110"><ChevronRight size={32}/></button>
          </div>
          <div className="flex-1 flex justify-end gap-3">
             <button onClick={() => setIsSpeedMenuOpen(!isSpeedMenuOpen)} className="px-4 py-2 bg-slate-50 rounded-xl text-slate-600 font-black text-[10px]">{playbackRate}x</button>
             {isSpeedMenuOpen && (
                <div className="absolute bottom-full right-6 mb-4 w-24 bg-white rounded-2xl shadow-2xl border p-2 flex flex-col z-[110]">
                   {[0.75, 1, 1.25, 1.5, 2].map(r => (
                      <button key={r} onClick={() => {setPlaybackRate(r); setIsSpeedMenuOpen(false);}} className={`p-2.5 hover:bg-slate-50 rounded-lg text-[11px] font-bold ${playbackRate === r ? 'text-emerald-600 bg-emerald-50' : 'text-slate-600'}`}>{r}x</button>
                   ))}
                </div>
             )}
          </div>
        </div>
      </div>

      {currentAyah?.audioUrl && (
        <audio 
          key={`audio-${currentAyah.ayahKey}-${selectedReciter}`}
          ref={audioRef}
          src={currentAyah.audioUrl}
          onTimeUpdate={handleTimeUpdate}
          onEnded={handleEnded}
          preload="auto"
        />
      )}
    </div>
  );
};

export default Learning;
