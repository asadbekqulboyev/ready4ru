
import React, { useEffect, useState } from 'react';
import { 
  ShieldCheck, Brain, Mic, ChevronRight, 
  PlayCircle, Star, Award, CheckCircle2, 
  ArrowRight, Heart, Sparkles, LayoutGrid, Zap,
  Globe, Users, Smartphone, Send
} from 'lucide-react';

interface LandingPageProps {
  onStart: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onStart }) => {
  const [scrolled, setScrolled] = useState(false);
  const [showLogin, setShowLogin] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (showLogin) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6 animate-in fade-in duration-500">
         <div className="w-full max-w-lg bg-white rounded-[3.5rem] p-12 shadow-2xl border border-slate-100 space-y-12">
            <div className="text-center space-y-4">
               <div className="w-16 h-16 bg-emerald-600 rounded-3xl mx-auto flex items-center justify-center text-white shadow-xl shadow-emerald-100">
                  <span className="text-2xl font-black">H</span>
               </div>
               <h2 className="text-3xl font-black text-slate-900">Xush kelibsiz</h2>
               <p className="text-slate-500 font-medium">Hifz sayohatingizni davom ettirish uchun tizimga kiring</p>
            </div>

            <div className="space-y-4">
               <button onClick={onStart} className="w-full py-4 bg-white border-2 border-slate-100 rounded-2xl flex items-center justify-center gap-4 hover:border-emerald-500 transition-all group">
                  <img src="https://www.google.com/favicon.ico" className="w-5 h-5" alt="Google" />
                  <span className="font-black text-slate-700 uppercase tracking-widest text-xs">Google bilan kirish</span>
               </button>
               <button onClick={onStart} className="w-full py-4 bg-white border-2 border-slate-100 rounded-2xl flex items-center justify-center gap-4 hover:border-emerald-500 transition-all group">
                  <Send className="text-sky-500" size={20} />
                  <span className="font-black text-slate-700 uppercase tracking-widest text-xs">Telegram bilan kirish</span>
               </button>
               <div className="relative py-4">
                  <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-100"></div></div>
                  <div className="relative flex justify-center text-xs uppercase font-black text-slate-300 bg-white px-4 tracking-widest">Yoki</div>
               </div>
               <div className="space-y-2">
                  <div className="relative">
                     <Smartphone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                     <input type="tel" placeholder="+998 00 000 00 00" className="w-full bg-slate-50 border-none rounded-2xl py-4 pl-12 pr-6 font-black text-slate-800 outline-none focus:ring-2 ring-emerald-100" />
                  </div>
                  <button onClick={onStart} className="w-full py-5 bg-emerald-600 text-white rounded-2xl font-black uppercase tracking-[0.2em] shadow-xl shadow-emerald-100 hover:bg-emerald-700 transition-all active:scale-95">Tasdiqlash kodini olish</button>
               </div>
            </div>

            <button onClick={() => setShowLogin(false)} className="w-full text-center text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-emerald-600 transition-colors">Orqaga qaytish</button>
         </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white selection:bg-emerald-100 text-slate-900 overflow-x-hidden scroll-smooth">
      {/* Navigation (o'zgarishsiz) */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? 'py-3' : 'py-6'}`}>
        <div className="max-w-6xl mx-auto px-6">
          <div className={`flex items-center justify-between px-6 py-3 rounded-2xl transition-all duration-500 ${scrolled ? 'bg-white/80 backdrop-blur-xl shadow-[0_8px_32px_rgba(0,0,0,0.05)] border border-white/20' : 'bg-transparent'}`}>
            <div className="flex items-center gap-2.5 group cursor-pointer">
              <div className="w-9 h-9 bg-emerald-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-emerald-200/50">
                <span className="font-serif font-black text-xl">H</span>
              </div>
              <h1 className="font-black text-slate-900 tracking-tight text-xl">Hafiz<span className="text-emerald-600">AI</span></h1>
            </div>
            <button onClick={() => setShowLogin(true)} className="bg-slate-900 text-white px-7 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-emerald-600 transition-all shadow-lg">Boshlash</button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-48 pb-32 px-6 overflow-hidden">
        <div className="max-w-6xl mx-auto text-center space-y-12">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-emerald-50 text-emerald-700 rounded-full border border-emerald-100/50">
            <Sparkles size={14} className="animate-pulse" />
            <span className="text-[10px] font-black uppercase tracking-widest">Professional Hifz Platformasi</span>
          </div>
          <h1 className="text-6xl md:text-8xl font-black text-slate-900 tracking-tight leading-[0.95]">
            Qur'onni <span className="text-emerald-600">Aqlli</span> <br/> usulda yodlang.
          </h1>
          <p className="text-xl text-slate-500 font-medium max-w-2xl mx-auto">
            Gemini 2.5 Pro texnologiyasi bilan qiroatingizni tahlil qiling va shaxsiy takomillashtirilgan reja asosida harakat qiling.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
             <button onClick={() => setShowLogin(true)} className="w-full sm:w-auto bg-emerald-600 text-white px-12 py-5 rounded-[2rem] font-black uppercase tracking-widest shadow-2xl shadow-emerald-100 hover:bg-emerald-700 hover:-translate-y-1 transition-all">Bepul boshlash</button>
             <button className="w-full sm:w-auto px-10 py-5 bg-white border border-slate-100 rounded-[2rem] font-black uppercase tracking-widest text-slate-600 hover:bg-slate-50 transition-all">Demo ko'rish</button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
