
import React, { useState, useMemo } from 'react';
import { 
  Layout, Star, Award, Zap, TrendingUp, 
  CheckCircle2, AlertTriangle, Send, 
  ArrowRight, ShieldCheck, Sparkles, MessageSquare,
  BarChart3, Target
} from 'lucide-react';
import { Surah, HifzPlanJSON } from '../types';
import { SURAHS_LIST } from '../constants';

interface DashboardProps {
  onSelectSurah: (surah: Surah) => void;
  onStartPlanning: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onSelectSurah, onStartPlanning }) => {
  const [accuracy, setAccuracy] = useState(100);
  const [errors, setErrors] = useState(0);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const activePlanStr = localStorage.getItem('active_hifz_plan');
  const activePlan: HifzPlanJSON | null = activePlanStr ? JSON.parse(activePlanStr) : null;

  const todayTask = useMemo(() => {
    if (!activePlan) return null;
    const todayStr = new Date().toISOString().split('T')[0];
    return activePlan.dailyTasks.find(t => t.date === todayStr);
  }, [activePlan]);

  const stats = [
    { label: "Yodlangan", value: "156", icon: Award, color: "text-emerald-600" },
    { label: "Bugun", value: todayTask ? `${todayTask.surahName}` : "—", icon: Zap, color: "text-amber-500" },
    { label: "Xatolar", value: errors.toString(), icon: AlertTriangle, color: "text-rose-500" },
    { label: "Yulduzlar", value: "24", icon: Star, color: "text-yellow-500" },
  ];

  const generateReport = () => {
    const text = `
🌙 *Hofiz AI: Kunlik Hisobot*
📅 Sana: ${new Date().toLocaleDateString()}
📖 Vazifa: ${todayTask?.surahName} (${todayTask?.startAyah}-${todayTask?.endAyah})
✅ Holat: ${accuracy}% bajarildi
❌ Xatolar: ${errors} ta
📈 AI Tavsiyasi: ${accuracy > 95 ? "Mukammal! Ertaga yuklamani biroz oshiramiz." : "Mustahkamlang. Ertaga yuklama 10% kamaytiriladi."}

_Muvaffaqiyat Allohdandir!_
    `;
    const encoded = encodeURIComponent(text);
    window.open(`https://t.me/share/url?url=${encoded}`, '_blank');
  };

  return (
    <div className="p-4 md:p-10 max-w-7xl mx-auto space-y-8 animate-slide-up pb-40">
      
      {/* STATS GRID - Mobil uchun optimallashgan */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s, i) => (
          <div key={i} className="bg-white p-5 rounded-[2rem] shadow-sm border border-slate-100 flex flex-col sm:flex-row items-center gap-4 hover:shadow-md transition-all active:scale-95 group">
            <div className={`p-4 rounded-2xl bg-slate-50 ${s.color} shrink-0 group-hover:scale-110 transition-transform`}>
              <s.icon size={22} />
            </div>
            <div className="text-center sm:text-left min-w-0">
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 truncate mb-0.5">{s.label}</p>
              <p className="text-xl font-black text-slate-800 truncate">{s.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* LEFT: BUGUNGI VAZIFA (Foydalanuvchi hayotiy sikli) */}
        <div className="lg:col-span-8 space-y-8">
          {activePlan ? (
            <div className="bg-white p-6 md:p-10 rounded-[3rem] shadow-sm border border-slate-100 space-y-8 relative overflow-hidden">
               <div className="absolute top-0 right-0 p-12 opacity-[0.02] pointer-events-none rotate-12"><Zap size={300} /></div>
               
               <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 relative z-10">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-600 shadow-sm"><CheckCircle2 size={28} /></div>
                    <div>
                      <h3 className="text-2xl font-black text-slate-800 tracking-tight">Bugungi Hifz</h3>
                      <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest">Yutuqlaringizni qayd eting</p>
                    </div>
                  </div>
                  {todayTask && <span className="bg-slate-900 text-white px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-widest shadow-xl">{todayTask.date?.split('-').reverse().join('.')}</span>}
               </div>

               {todayTask ? (
                 <div className="space-y-10 relative z-10">
                    <div className="flex flex-col md:flex-row items-center gap-8 p-8 bg-slate-50/50 rounded-[2.5rem] border border-slate-100">
                       <div className="flex-1 space-y-3 text-center md:text-left">
                          <p className="text-[11px] font-black text-emerald-600 uppercase tracking-widest bg-emerald-50 inline-block px-3 py-1 rounded-lg">Navbatdagi Manzil</p>
                          <h4 className="text-5xl font-black text-slate-900 tracking-tighter leading-none">{todayTask.surahName}</h4>
                          <p className="text-xl font-bold text-slate-500">{todayTask.startAyah} - {todayTask.endAyah} oyatlar</p>
                       </div>
                       <div className="w-full md:w-72 space-y-8">
                          <div className="space-y-3">
                             <div className="flex justify-between items-end"><span className="text-[11px] font-black uppercase text-slate-400">O'zlashtirish</span> <span className="text-xl font-black text-emerald-600">{accuracy}%</span></div>
                             <input type="range" min="0" max="100" value={accuracy} onChange={(e) => setAccuracy(Number(e.target.value))} className="w-full h-3 bg-slate-200 rounded-full appearance-none cursor-pointer accent-emerald-500" />
                          </div>
                          <div className="space-y-3">
                             <div className="flex justify-between items-end"><span className="text-[11px] font-black uppercase text-slate-400">Xatolar</span> <span className="text-xl font-black text-rose-500">{errors} ta</span></div>
                             <div className="flex items-center gap-3">
                                <button onClick={() => setErrors(Math.max(0, errors - 1))} className="flex-1 h-14 bg-white border-2 border-slate-100 rounded-2xl flex items-center justify-center font-black text-2xl hover:bg-slate-50 transition-colors shadow-sm">-</button>
                                <button onClick={() => setErrors(errors + 1)} className="flex-1 h-14 bg-white border-2 border-slate-100 rounded-2xl flex items-center justify-center font-black text-2xl hover:bg-slate-50 transition-colors shadow-sm">+</button>
                             </div>
                          </div>
                       </div>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-4">
                       <button onClick={() => setIsSubmitted(true)} className="flex-1 py-5 bg-emerald-600 text-white rounded-[1.5rem] font-black uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-2xl shadow-emerald-100 flex items-center justify-center gap-3 active:scale-95">
                         <ShieldCheck size={20} /> Tasdiqlash
                       </button>
                       <button onClick={generateReport} className="flex-1 py-5 bg-slate-900 text-white rounded-[1.5rem] font-black uppercase tracking-widest hover:bg-slate-800 transition-all shadow-2xl flex items-center justify-center gap-3 active:scale-95">
                         <Send size={18} /> Telegramga ulashish
                       </button>
                    </div>

                    {isSubmitted && (
                      <div className="p-8 bg-emerald-50 rounded-[2.5rem] border border-emerald-100 flex items-start gap-6 animate-in slide-in-from-top-4">
                         <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-emerald-600 shadow-md shrink-0"><Sparkles size={28} /></div>
                         <div className="space-y-1">
                            <h5 className="text-lg font-black text-emerald-900">AI Adaptive Monitoring</h5>
                            <p className="text-[13px] font-medium text-emerald-700/80 leading-relaxed">
                              Natijangiz qayd etildi. {accuracy >= 95 ? "Zo'r natija! Ertangi yuklamani o'z holida qoldiramiz." : "Xavotirlanmang, ertaga yuklamani 15% ga kamaytirib, takrorlashga e'tibor qaratamiz."}
                            </p>
                         </div>
                      </div>
                    )}
                 </div>
               ) : (
                 <div className="text-center py-20 space-y-6">
                    <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto text-slate-200"><BarChart3 size={40} /></div>
                    <p className="text-slate-400 font-bold max-w-xs mx-auto">Bugun uchun rejalashtirilgan vazifalar yakunlangan yoki mavjud emas.</p>
                    <button onClick={onStartPlanning} className="bg-slate-900 text-white px-8 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-emerald-600 transition-all">Yangi reja tuzish</button>
                 </div>
               )}
            </div>
          ) : (
            <div className="bg-emerald-900 rounded-[3.5rem] p-8 md:p-16 text-white relative overflow-hidden shadow-2xl">
               <div className="absolute top-0 right-0 p-20 opacity-10 pointer-events-none"><Zap size={400} /></div>
               <div className="relative z-10 space-y-8 text-center md:text-left">
                  <div className="w-20 h-20 bg-white/10 backdrop-blur-xl rounded-[2rem] flex items-center justify-center mx-auto md:mx-0 shadow-2xl"><Award size={40} /></div>
                  <div className="space-y-3">
                    <h2 className="text-4xl md:text-5xl font-black tracking-tight leading-none">Hifz sayohatingizni boshlang!</h2>
                    <p className="text-emerald-100/60 font-medium max-w-md mx-auto md:mx-0">AI texnologiyasi yordamida Qur'onni yodlash endi yanada tizimli va oson.</p>
                  </div>
                  <button onClick={onStartPlanning} className="w-full sm:w-auto bg-white text-emerald-900 px-12 py-5 rounded-2xl font-black uppercase tracking-[0.2em] hover:bg-emerald-50 transition-all shadow-2xl flex items-center justify-center gap-3">
                    REJA TUZISH <ArrowRight size={20} />
                  </button>
               </div>
            </div>
          )}
        </div>

        {/* RIGHT: INSIGHTS & TARGETS */}
        <div className="lg:col-span-4 space-y-8">
           <div className="bg-white p-8 rounded-[3rem] shadow-sm border border-slate-100 space-y-6 group">
              <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                <MessageSquare size={12} className="text-emerald-500" /> AI Ustoz Fikri
              </h4>
              <div className="flex gap-4 p-5 bg-slate-50 rounded-[2rem] border border-slate-100 group-hover:bg-white transition-colors">
                 <p className="text-[13px] font-bold text-slate-600 leading-relaxed italic">
                   "Vazifangizni muvaffaqiyatli yakunladingiz. Takrorlashda ayniqsa 'madda' qoidalariga ko'proq e'tibor qarating."
                 </p>
              </div>
           </div>

           <div className="bg-white p-8 rounded-[3rem] shadow-sm border border-slate-100 space-y-6">
              <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                <Target size={12} className="text-emerald-500" /> Tanlangan Suralar
              </h4>
              <div className="space-y-3">
                 {activePlan?.selectedSurahs?.slice(0, 4).map(sNum => {
                   const surah = SURAHS_LIST.find(s => s.number === sNum);
                   return (
                    <div key={sNum} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100 hover:bg-emerald-50 hover:border-emerald-100 transition-colors cursor-default">
                       <span className="text-xs font-black text-slate-800 uppercase tracking-tighter">{surah?.englishName}</span>
                       <span className="text-[9px] font-black text-emerald-600 uppercase">Jarayonda</span>
                    </div>
                   );
                 })}
                 {(!activePlan || activePlan.selectedSurahs.length === 0) && (
                   <div className="py-10 text-center space-y-2">
                     <p className="text-xs text-slate-300 font-black uppercase">Suralar tanlanmagan</p>
                   </div>
                 )}
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
