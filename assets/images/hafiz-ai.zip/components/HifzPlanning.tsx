
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
  Target, Clock, BookOpen, Search, 
  Calendar as CalendarIcon, Zap, Flag,
  ChevronUp, ChevronDown, ChevronLeft, ChevronRight,
  FileDown, LayoutGrid, BellRing, Send, Smartphone,
  Info, Table as TableIcon, Download, CheckCircle2,
  Sparkles, BrainCircuit, AlertCircle, Loader2, ClipboardCheck,
  FileText, History, Settings
} from 'lucide-react';
import { GoogleGenAI, Type } from "@google/genai";
import { SURAHS_LIST } from '../constants';
import { DailyTask, HifzPlanJSON } from '../types';
import { hifzService } from '../services/api';

interface HifzPlanningProps {
  onPlanSaved: (plan: HifzPlanJSON) => void;
}

const ModernDatePicker = ({ label, value, onChange }: { label: string, value: string, onChange: (v: string) => void }) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const months = ["Yanvar", "Fevral", "Mart", "Aprel", "May", "Iyun", "Iyul", "Avgust", "Sentabr", "Oktabr", "Noyabr", "Dekabr"];
  const date = value ? new Date(value) : new Date();
  const [viewDate, setViewDate] = useState(new Date(date.getFullYear(), date.getMonth(), 1));

  const handleDateSelect = (day: number) => {
    const selected = new Date(viewDate.getFullYear(), viewDate.getMonth(), day);
    const dateStr = selected.toISOString().split('T')[0];
    onChange(dateStr);
    setIsOpen(false);
  };

  return (
    <div className="relative flex-1 space-y-2" ref={containerRef}>
      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{label}</label>
      <div className="relative group">
        <input 
          type="text" value={value || 'Tanlanmagan'} readOnly
          className="w-full bg-slate-50 border border-slate-100 rounded-2xl p-4 pl-12 pr-10 font-bold text-slate-800 text-sm cursor-pointer hover:bg-slate-100 transition-all outline-none focus:ring-2 ring-emerald-500/20"
          onClick={() => setIsOpen(!isOpen)}
        />
        <CalendarIcon size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-emerald-500" />
      </div>

      {isOpen && (
        <div className="absolute top-full left-0 right-0 z-[110] mt-3 bg-white rounded-3xl shadow-2xl border border-slate-100 p-5 animate-in fade-in zoom-in duration-200 min-w-[280px]">
          <div className="flex items-center justify-between mb-4">
            <button onClick={() => setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() - 1, 1))} className="p-2 hover:bg-slate-50 rounded-xl"><ChevronLeft size={16}/></button>
            <span className="font-black text-slate-800 text-[11px] uppercase tracking-widest">{months[viewDate.getMonth()]} {viewDate.getFullYear()}</span>
            <button onClick={() => setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 1))} className="p-2 hover:bg-slate-50 rounded-xl"><ChevronRight size={16}/></button>
          </div>
          <div className="grid grid-cols-7 gap-1">
            {Array.from({ length: 31 }).map((_, i) => (
              <button key={i} onClick={() => handleDateSelect(i + 1)} className="aspect-square rounded-xl text-[11px] font-bold hover:bg-emerald-50 transition-colors">{i + 1}</button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

const HifzPlanning: React.FC<HifzPlanningProps> = ({ onPlanSaved }) => {
  const [strategy, setStrategy] = useState<'whole' | 'custom'>('custom');
  const [selectedSurahs, setSelectedSurahs] = useState<number[]>([]);
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState<string>(''); 
  const [morningTime, setMorningTime] = useState('07:30');
  const [eveningTime, setEveningTime] = useState('21:00');
  const [dailyTasks, setDailyTasks] = useState<DailyTask[]>([]);
  const [isAiGenerating, setIsAiGenerating] = useState(false);
  const [loadingStep, setLoadingStep] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSaved, setIsSaved] = useState(false);

  const diffDays = useMemo(() => {
    if (!endDate) return 0;
    const start = new Date(startDate);
    const end = new Date(endDate);
    return Math.max(1, Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)));
  }, [startDate, endDate]);

  const generateSmartPlan = async () => {
    if (diffDays <= 0) {
      alert("Iltimos, avval yakuniy sanani belgilang.");
      return;
    }
    if (strategy === 'custom' && selectedSurahs.length === 0) {
      alert("Iltimos, kamida bitta surani tanlang.");
      return;
    }

    setIsAiGenerating(true);
    setLoadingStep('Oyatlar hajmi tahlil qilinmoqda...');

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const selectedSurahData = strategy === 'whole' 
      ? "Butun Qur'on (30 Juz, barcha suralar)" 
      : SURAHS_LIST.filter(s => selectedSurahs.includes(s.number))
          .map(s => `${s.englishName} surasi (${s.numberOfAyahs} oyat)`).join(', ');

    const prompt = `
      Siz professional Qur'on Hifzi (yodlash) bo'yicha mutaxassis va aqlli algoritmsiz. 
      Vazifa: Berilgan suralarni ${diffDays} kun ichida yodlash uchun MUVOZANATLI (balanced) va AQLLI reja tuzing.

      Suralar: ${selectedSurahData}.
      Boshlanish sanasi: ${startDate}.

      MUHIM KO'RSATMA:
      Qur'on oyatlarining matn hajmi turlicha. Masalan, Baqara 282-oyati 1 sahifaga yaqin, lekin Nos surasi oyatlari juda qisqa.
      Siz har bir kunlik yuklamani OYATLAR SONI bo'yicha emas, balki OYATLARNING MATN HAJMI va YODLASH QIYINLIGI (word count/complexity) bo'yicha teng taqsimlang.
      - 1 ta uzun oyat bor kun uchun 1 ta vazifa bering.
      - 10 ta juda qisqa oyat bor kun uchun (hajmi uzun oyat bilan teng bo'lsa) o'sha 10 ta oyatni bitta kunga bering.
      - Yuklama har kuni taxminan bir xil bo'lishi kerak.
      - Har bir kun vazifasini mantiqiy yakunlangan blok (masalan, oyat yakuni) sifatida belgilang.
      - Jami ${diffDays} kunga to'liq sig'diring.

      Javobni FAQAT JSON formatida qaytaring, hech qanday matn qo'shmang:
      [
        {
          "day": number,
          "surahName": string,
          "surahNumber": number,
          "startAyah": number,
          "endAyah": number,
          "date": "YYYY-MM-DD",
          "isCompleted": false
        }
      ]
    `;

    try {
      setTimeout(() => setLoadingStep('AI Strategiya ishlab chiqmoqda...'), 2000);
      setTimeout(() => setLoadingStep('Kunlik yuklamalar muvozanatlanmoqda...'), 4000);

      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview', // Yuqori aniqlik uchun pro model
        contents: [{ parts: [{ text: prompt }] }],
        config: {
          responseMimeType: "application/json",
          thinkingConfig: { thinkingBudget: 4000 }, // AI oyat hajmlarini tahlil qilishi uchun vaqt beramiz
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                day: { type: Type.NUMBER },
                surahName: { type: Type.STRING },
                surahNumber: { type: Type.NUMBER },
                startAyah: { type: Type.NUMBER },
                endAyah: { type: Type.NUMBER },
                date: { type: Type.STRING },
                isCompleted: { type: Type.BOOLEAN }
              },
              required: ["day", "surahName", "surahNumber", "startAyah", "endAyah", "date", "isCompleted"]
            }
          }
        }
      });

      const planData = JSON.parse(response.text);
      setDailyTasks(planData);
    } catch (error) {
      console.error("Smart Plan Generation Error:", error);
      alert("Reja tuzishda xatolik yuz berdi. Iltimos qaytadan urinib ko'ring.");
    } finally {
      setIsAiGenerating(false);
      setLoadingStep('');
    }
  };

  const handleConfirmFinal = async () => {
    if (dailyTasks.length === 0) return;

    const plan: HifzPlanJSON = {
      strategy,
      selectedSurahs,
      startDate,
      endDate,
      morningReminder: morningTime,
      eveningReminder: eveningTime,
      totalAyahs: dailyTasks.reduce((acc, t) => acc + (t.endAyah - t.startAyah + 1), 0),
      dailyTasks,
      notificationMethods: ['push', 'telegram']
    };

    try {
      setLoadingStep('Reja serverga saqlanmoqda...');
      const response = await hifzService.savePlan(plan);
      if (response.success) {
        setIsSaved(true);
        onPlanSaved(plan);
      }
    } catch (e) {
      console.error("Save plan error", e);
      // Fallback: local storage or prompt
      onPlanSaved(plan);
    } finally {
      setLoadingStep('');
    }
  };

  const downloadPlanPDF = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const rows = dailyTasks.map(t => `
      <tr style="border-bottom: 1px solid #f1f5f9;">
        <td style="padding: 12px; font-weight: 800; color: #64748b;">${t.day}</td>
        <td style="padding: 12px; font-weight: 600; color: #475569;">${t.date?.split('-').reverse().join('.')}</td>
        <td style="padding: 12px; font-weight: 900; color: #059669; text-transform: uppercase;">${t.surahName}</td>
        <td style="padding: 12px; font-weight: 700; color: #1e293b;">${t.startAyah} - ${t.endAyah} oyatlar</td>
        <td style="padding: 12px; text-align: center;"><div style="width: 18px; height: 18px; border: 2px solid #cbd5e1; border-radius: 4px; display: inline-block;"></div></td>
      </tr>
    `).join('');

    printWindow.document.write(`
      <html>
        <head>
          <title>Hofiz AI - Shaxsiy Reja</title>
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;700;800&display=swap');
            body { font-family: 'Plus Jakarta Sans', sans-serif; padding: 40px; color: #1e293b; background: #fff; }
            .header { text-align: center; border-bottom: 4px solid #059669; padding-bottom: 20px; margin-bottom: 30px; }
            .title { font-size: 28px; font-weight: 800; color: #0f172a; margin: 0; }
            .subtitle { font-size: 14px; font-weight: 600; color: #64748b; text-transform: uppercase; letter-spacing: 2px; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th { text-align: left; padding: 12px; font-size: 11px; text-transform: uppercase; color: #94a3b8; border-bottom: 2px solid #e2e8f0; }
            .footer { margin-top: 50px; text-align: center; font-size: 12px; color: #94a3b8; border-top: 1px solid #f1f5f9; padding-top: 20px; }
          </style>
        </head>
        <body>
          <div class="header">
            <p class="subtitle">Hofiz AI Professional</p>
            <h1 class="title">Aqlli Hifz Rejasi</h1>
            <p style="font-weight: 700; color: #059669; margin-top: 10px;">${startDate} — ${endDate}</p>
          </div>
          <table>
            <thead>
              <tr><th>Kun</th><th>Sana</th><th>Sura Nomi</th><th>Oyatlar</th><th>Bajarildi</th></tr>
            </thead>
            <tbody>${rows}</tbody>
          </table>
          <div class="footer">Ushbu reja Gemini AI tomonidan oyatlar hajmi va murakkabligini hisobga olgan holda tuzildi.</div>
          <script>window.onload = () => { window.print(); window.close(); }</script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div className="p-4 md:p-10 max-w-7xl mx-auto space-y-10 animate-slide-up pb-40">
      <div className="flex flex-col lg:flex-row gap-10 items-start">
        
        {/* LEFT PANEL: CONFIGURATION */}
        <div className="w-full lg:flex-1 space-y-8">
          
          {/* STEP 1: SCOPE */}
          <div className="bg-white p-6 md:p-10 rounded-[3rem] shadow-sm border border-slate-100 space-y-8">
            <div className="flex items-center justify-between">
               <h3 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
                 <Target size={16} className="text-emerald-500" /> 1. Hifz Qamrovi
               </h3>
               <div className="px-3 py-1 bg-emerald-50 text-emerald-600 rounded-lg text-[10px] font-black">AI ANALIZI YOQILGAN</div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <button onClick={() => setStrategy('whole')} className={`p-8 rounded-[2.5rem] border-2 transition-all flex flex-col gap-4 text-left ${strategy === 'whole' ? 'border-emerald-500 bg-emerald-50/20 shadow-xl' : 'border-slate-50 bg-slate-50/50 hover:bg-slate-100'}`}>
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${strategy === 'whole' ? 'bg-emerald-600 text-white shadow-lg' : 'bg-white text-slate-300'}`}><BookOpen size={28}/></div>
                <div><p className="font-black text-slate-800 text-lg">Butun Qur'on</p><p className="text-[11px] font-bold text-slate-400 uppercase">30 Juz To'liq</p></div>
              </button>
              <button onClick={() => setStrategy('custom')} className={`p-8 rounded-[2.5rem] border-2 transition-all flex flex-col gap-4 text-left ${strategy === 'custom' ? 'border-emerald-500 bg-emerald-50/20 shadow-xl' : 'border-slate-50 bg-slate-50/50 hover:bg-slate-100'}`}>
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${strategy === 'custom' ? 'bg-emerald-600 text-white shadow-lg' : 'bg-white text-slate-300'}`}><LayoutGrid size={28}/></div>
                <div><p className="font-black text-slate-800 text-lg">Maxsus Suralar</p><p className="text-[11px] font-bold text-slate-400 uppercase">{selectedSurahs.length} sura tanlandi</p></div>
              </button>
            </div>

            {strategy === 'custom' && (
              <div className="pt-4 space-y-6">
                <div className="relative">
                  <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                  <input type="text" placeholder="Sura nomini yozing..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="w-full bg-slate-50 rounded-[1.5rem] py-5 pl-14 pr-6 text-sm font-bold border-none outline-none focus:ring-2 ring-emerald-100" />
                </div>
                <div className="flex flex-wrap gap-2 max-h-60 overflow-y-auto custom-scrollbar p-2">
                  {SURAHS_LIST.filter(s => s.englishName.toLowerCase().includes(searchQuery.toLowerCase())).map(s => (
                    <button key={s.number} onClick={() => setSelectedSurahs(prev => prev.includes(s.number) ? prev.filter(n => n !== s.number) : [...prev, s.number])} className={`px-5 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${selectedSurahs.includes(s.number) ? 'bg-emerald-600 text-white shadow-lg' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}>
                      {s.englishName}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* STEP 2: TIMEFRAME */}
          <div className="bg-white p-6 md:p-10 rounded-[3rem] shadow-sm border border-slate-100 space-y-8">
            <h3 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
              <Clock size={16} className="text-emerald-500" /> 2. Muddat va Intensivlik
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <ModernDatePicker label="Boshlash Sanasi" value={startDate} onChange={setStartDate} />
              <ModernDatePicker label="Yakunlash Sanasi" value={endDate} onChange={setEndDate} />
            </div>
            {diffDays > 0 && (
                <div className="bg-slate-900 text-white p-8 rounded-[2.5rem] flex items-center justify-between shadow-2xl relative overflow-hidden group">
                   <Zap className="absolute -top-4 -right-4 w-32 h-32 text-white/5 group-hover:scale-110 transition-transform" />
                   <div className="relative z-10">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-1">Marafoni Davomiyligi</p>
                      <h4 className="text-4xl font-black">{diffDays} Kun</h4>
                   </div>
                   <div className="w-16 h-16 bg-emerald-500 rounded-2xl flex items-center justify-center shadow-xl shadow-emerald-500/20">
                      <CalendarIcon size={32} />
                   </div>
                </div>
            )}
          </div>
        </div>

        {/* RIGHT PANEL: AI SUMMARY & ACTION */}
        <div className="w-full lg:w-96 shrink-0 space-y-6">
          <div className="bg-white p-8 rounded-[3rem] shadow-2xl border border-slate-100 space-y-8 sticky top-24">
             <div className="text-center lg:text-left space-y-1">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Tizim holati</p>
                <h4 className="text-3xl font-black text-slate-900 tracking-tight">AI Muallim</h4>
             </div>

             <div className="p-6 bg-emerald-600 rounded-[2.5rem] text-white relative overflow-hidden shadow-xl shadow-emerald-200 group">
                <BrainCircuit className="absolute -top-4 -right-4 w-24 h-24 text-white/10 group-hover:scale-110 transition-transform" />
                <div className="relative z-10 space-y-4">
                   <div className="flex items-center gap-2">
                      <Sparkles size={16} className="text-emerald-200" />
                      <span className="text-[10px] font-black uppercase tracking-[0.2em] text-emerald-100">Deep Text Analysis</span>
                   </div>
                   <p className="text-[13px] font-bold leading-relaxed">
                      Gemini 3 Pro har bir oyatning so'z boyligini tahlil qiladi. Reja nafaqat oyat soniga, balki ularning haqiqiy "vazniga" qarab tuziladi.
                   </p>
                </div>
             </div>

             {loadingStep && (
                <div className="p-6 bg-slate-50 rounded-[2rem] border border-slate-100 flex items-center gap-4 animate-pulse">
                   <Loader2 className="animate-spin text-emerald-500" size={20} />
                   <p className="text-[11px] font-black text-slate-600 uppercase tracking-widest">{loadingStep}</p>
                </div>
             )}

             <div className="space-y-3">
                <button 
                  onClick={generateSmartPlan}
                  disabled={isAiGenerating || !endDate}
                  className="w-full py-5 bg-slate-900 text-white rounded-[1.5rem] font-black uppercase tracking-widest hover:bg-emerald-600 disabled:opacity-30 transition-all flex items-center justify-center gap-3 shadow-xl active:scale-95"
                >
                  {isAiGenerating ? <Loader2 className="animate-spin" size={20} /> : <Zap size={20} />}
                  Aqlli Reja Generatsiyasi
                </button>
                {dailyTasks.length > 0 && (
                   <button 
                     onClick={handleConfirmFinal}
                     className={`w-full py-5 text-white rounded-[1.5rem] font-black uppercase tracking-widest shadow-2xl transition-all active:scale-95 flex items-center justify-center gap-3 ${isSaved ? 'bg-slate-400 cursor-default' : 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-100'}`}
                   >
                     {isSaved ? <CheckCircle2 size={20} /> : <ClipboardCheck size={20} />}
                     {isSaved ? 'Reja Tasdiqlangan' : 'Rejani Tasdiqlash'}
                   </button>
                )}
             </div>
          </div>
        </div>
      </div>

      {/* SCHEDULE TABLE */}
      {dailyTasks.length > 0 && (
        <div className="bg-white p-6 md:p-12 rounded-[4rem] shadow-sm border border-slate-100 space-y-12 animate-slide-up">
           <div className="flex flex-col sm:flex-row items-center justify-between gap-6 border-b border-slate-50 pb-8">
              <div className="flex items-center gap-5">
                 <div className="w-16 h-16 bg-slate-900 text-white rounded-[2rem] flex items-center justify-center shadow-2xl"><TableIcon size={32} /></div>
                 <div>
                    <h3 className="text-2xl font-black text-slate-900 tracking-tight">O'quv Jadvali</h3>
                    <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest">Oyatlar hajmiga ko'ra tahlil qilingan (AI Balanced)</p>
                 </div>
              </div>
              <button 
                onClick={downloadPlanPDF}
                className="w-full sm:w-auto px-10 py-5 bg-emerald-50 text-emerald-700 rounded-3xl font-black uppercase tracking-widest text-[10px] hover:bg-emerald-100 transition-all flex items-center justify-center gap-3 shadow-sm border border-emerald-100"
              >
                <Download size={18} /> Rejani Yuklab Olish (PDF)
              </button>
           </div>

           <div className="overflow-x-auto rounded-[2.5rem] border border-slate-50">
              <table className="w-full text-left">
                 <thead>
                    <tr className="bg-slate-50/50">
                       <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">Kun</th>
                       <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">Sana</th>
                       <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">Vazifa</th>
                       <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">Hajmi</th>
                       <th className="px-10 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Status</th>
                    </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-50">
                    {dailyTasks.map((t, i) => (
                      <tr key={i} className="hover:bg-slate-50/30 transition-colors group">
                         <td className="px-10 py-7 font-black text-slate-400 text-sm">Kun {t.day}</td>
                         <td className="px-10 py-7 font-bold text-slate-500 text-xs uppercase">{t.date?.split('-').reverse().join('.')}</td>
                         <td className="px-10 py-7">
                            <div className="space-y-1">
                               <p className="font-black text-slate-800 uppercase text-lg leading-tight">{t.surahName}</p>
                               <span className="inline-block px-3 py-1 bg-emerald-50 text-emerald-600 text-[10px] font-black rounded-lg">
                                 {t.startAyah} - {t.endAyah} oyatlar
                               </span>
                            </div>
                         </td>
                         <td className="px-10 py-7">
                            <div className="flex items-center gap-2">
                               <div className="flex gap-0.5">
                                  {[1,2,3,4].map(star => (
                                    <div key={star} className={`w-1.5 h-3 rounded-full ${star <= (t.endAyah - t.startAyah > 5 ? 3 : 2) ? 'bg-emerald-400' : 'bg-slate-100'}`} />
                                  ))}
                               </div>
                               <span className="text-[10px] font-black text-slate-400 uppercase">{t.endAyah - t.startAyah + 1} oyat</span>
                            </div>
                         </td>
                         <td className="px-10 py-7">
                            <div className="flex justify-center">
                               <div className="w-8 h-8 border-2 border-slate-100 rounded-xl flex items-center justify-center text-slate-200 group-hover:border-emerald-500 transition-colors">
                                  <CheckCircle2 size={18} />
                               </div>
                            </div>
                         </td>
                      </tr>
                    ))}
                 </tbody>
              </table>
           </div>
           
           <div className="p-8 bg-slate-900 rounded-[3rem] text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl">
              <div className="flex items-center gap-4">
                 <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center"><Info size={24} /></div>
                 <div>
                    <h5 className="font-black text-lg">AI Eslatmasi</h5>
                    <p className="text-slate-400 text-xs font-medium">Rejadagi oyatlar hajmi muvozanatlangan. Uzun oyatlar bor kunlari oyat soni kamroq etib belgilangan.</p>
                 </div>
              </div>
              <button onClick={downloadPlanPDF} className="w-full md:w-auto px-8 py-3 bg-white text-slate-900 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-emerald-500 hover:text-white transition-all">Nusxa Ko'chirish</button>
           </div>
        </div>
      )}
    </div>
  );
};

export default HifzPlanning;
