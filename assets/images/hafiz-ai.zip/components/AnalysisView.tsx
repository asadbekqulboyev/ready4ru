import React from 'react';
import { Search, Brain, Zap, ShieldCheck } from 'lucide-react';
import { Language } from '../types';

interface AnalysisViewProps {
  language: Language;
  onGoToAyah: (surah: number, ayah: number) => void;
}

const AnalysisView: React.FC<AnalysisViewProps> = () => {
  return (
    <div className="p-8 max-w-4xl mx-auto space-y-8 animate-slide-up">
      <div className="text-center space-y-4">
        <h2 className="text-3xl font-black text-slate-800">Qiroat Analitikasi</h2>
        <p className="text-slate-500 font-medium">Sun'iy intellekt yordamida hifz darajangizni tahlil qiling</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 space-y-4">
           <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center">
              <Brain size={24} />
           </div>
           <h3 className="text-lg font-black text-slate-800">Tajvid darajasi</h3>
           <p className="text-sm text-slate-400 font-bold leading-relaxed">Oxirgi 7 kundagi qiroatlaringiz asosida tajvid bo'yicha umumiy darajangiz: <span className="text-emerald-600">A+</span></p>
        </div>

        <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 space-y-4">
           <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center">
              <Zap size={24} />
           </div>
           <h3 className="text-lg font-black text-slate-800">Hifz mustahkamligi</h3>
           <p className="text-sm text-slate-400 font-bold leading-relaxed">Xotirangizdagi suralarning saqlanish darajasi 85% ni tashkil qiladi.</p>
        </div>
      </div>
      
      <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 flex items-center justify-between">
         <div className="flex items-center gap-4">
           <ShieldCheck size={32} className="text-emerald-500" />
           <div>
             <p className="text-sm font-black text-slate-800">Sertifikat olishga tayyorgarlik</p>
             <p className="text-xs font-bold text-slate-400">Sizda yana 3 ta surani topshirish imkoniyati bor.</p>
           </div>
         </div>
         <button className="bg-slate-900 text-white px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest">Ko'rish</button>
      </div>
    </div>
  );
};

export default AnalysisView;