
import React, { useState, useRef, useEffect } from 'react';
import { 
  Mic, RotateCcw, CheckCircle2, AlertCircle, 
  Loader2, Play, Pause, AlertTriangle, Sparkles,
  ChevronRight, ArrowRight, ShieldCheck
} from 'lucide-react';
import { Surah, AppMode } from '../types';
import { analyzeRecitation, blobToBase64 } from '../services/geminiService';
import { quranApi } from '../services/quran';

interface TestingProps {
  surah: Surah;
  onModeChange: (mode: AppMode) => void;
}

const Testing: React.FC<TestingProps> = ({ surah }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<any | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [canonicalText, setCanonicalText] = useState('');

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Oyat matnini yuklab olish (AI ga yuborish uchun)
  useEffect(() => {
    const fetchText = async () => {
      try {
        const data = await quranApi.getSurahData(surah.number);
        // Sinov uchun birinchi oyatni olamiz (yoki hozirgi tanlanganini)
        setCanonicalText(data[0]?.text || '');
      } catch (err) {
        console.error("Fetch text error", err);
      }
    };
    fetchText();
  }, [surah.number]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        handleAnalyze(audioBlob);
      };

      mediaRecorder.start();
      setIsRecording(true);
      setError(null);
    } catch (err) {
      setError("Mikrofonga ruxsat berilmadi yoki xatolik yuz berdi.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
    }
  };

  const handleAnalyze = async (blob: Blob) => {
    setIsAnalyzing(true);
    setResult(null);
    try {
      const base64Audio = await blobToBase64(blob);
      const analysis = await analyzeRecitation(
        surah.englishName,
        "1-oyat", // Oyat oralig'i
        canonicalText,
        base64Audio
      );
      setResult(analysis);
    } catch (err) {
      setError("Tahlil qilishda xatolik yuz berdi. Qayta urinib ko'ring.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const resetTest = () => {
    setResult(null);
    setError(null);
    setIsRecording(false);
  };

  return (
    <div className="h-full flex flex-col p-6 md:p-10 max-w-5xl mx-auto space-y-8 animate-slide-up">
      {/* Header Info */}
      <div className="flex items-center justify-between bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
        <div className="flex items-center gap-5">
           <div className="w-14 h-14 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-600">
              <ShieldCheck size={28} />
           </div>
           <div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Hozirgi Sinov</p>
              <h2 className="text-xl font-black text-slate-800">{surah.englishName} surasi, 1-oyat</h2>
           </div>
        </div>
        <div className="hidden md:flex flex-col items-end">
           <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">AI Ustoz Faol</p>
           <div className="flex gap-1 mt-1">
              {[1,2,3].map(i => <div key={i} className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" style={{ animationDelay: `${i*0.2}s` }} />)}
           </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col justify-center items-center text-center space-y-10 py-10">
        {!result && !isAnalyzing && (
          <div className="space-y-10 animate-slide-up">
            <div className={`w-32 h-32 rounded-[2.8rem] flex items-center justify-center transition-all duration-500 ${isRecording ? 'bg-red-500 text-white shadow-2xl shadow-red-200 scale-110' : 'bg-slate-100 text-slate-300'}`}>
               <Mic size={48} className={isRecording ? 'animate-pulse' : ''} />
            </div>
            <div className="space-y-3">
               <h2 className="text-3xl font-black text-slate-800">Qiroatni boshlang</h2>
               <p className="text-slate-500 font-medium max-w-sm mx-auto">
                 {isRecording ? "Sizni eshityapman, davom eting..." : "Oyatni yoddan o'qing. AI Ustoz tajvid va xatolarni tekshiradi."}
               </p>
            </div>
          </div>
        )}

        {isAnalyzing && (
          <div className="flex flex-col items-center gap-6 animate-pulse">
             <div className="relative">
                <div className="w-24 h-24 border-4 border-emerald-100 border-t-emerald-500 rounded-full animate-spin" />
                <Brain className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-emerald-500" size={32} />
             </div>
             <div className="space-y-2">
                <p className="text-lg font-black text-slate-800">Tahlil qilinmoqda...</p>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Tajvid va makharij tekshirilmoqda</p>
             </div>
          </div>
        )}

        {result && (
          <div className="w-full space-y-8 animate-slide-up">
            {/* Accuracy Card */}
            <div className={`relative p-10 rounded-[3rem] overflow-hidden ${result.accuracy >= 95 ? 'bg-emerald-600 text-white shadow-2xl shadow-emerald-200' : 'bg-white border-2 border-slate-100 shadow-xl'}`}>
               {result.is_perfect && <Sparkles className="absolute top-8 right-8 text-white/50 animate-bounce" size={40} />}
               <div className="relative z-10 flex flex-col items-center gap-6">
                  <div className={`w-24 h-24 rounded-full border-4 flex items-center justify-center ${result.accuracy >= 95 ? 'border-white/20 bg-white/10' : 'border-emerald-100 bg-emerald-50 text-emerald-600'}`}>
                    <span className="text-3xl font-black">{result.accuracy}%</span>
                  </div>
                  <div className="space-y-3">
                    <h3 className={`text-2xl font-black ${result.accuracy >= 95 ? 'text-white' : 'text-slate-800'}`}>
                      {result.is_perfect ? "Mukammal Qiroat!" : "Natija: " + result.accuracy + "%"}
                    </h3>
                    <p className={`text-sm font-bold max-w-lg mx-auto leading-relaxed ${result.accuracy >= 95 ? 'text-white/80' : 'text-slate-500'}`}>
                      {result.overall_summary}
                    </p>
                  </div>
               </div>
            </div>

            {/* Detailed Feedback */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
               {/* Mistakes */}
               <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm space-y-6">
                  <h4 className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-slate-400">
                    <AlertTriangle size={14} className="text-amber-500" /> Xatolar Ro'yxati
                  </h4>
                  {result.mistakes.length > 0 ? (
                    <div className="space-y-4">
                      {result.mistakes.map((m: any, i: number) => (
                        <div key={i} className="p-4 bg-slate-50 rounded-2xl border-l-4 border-amber-500">
                           <p className="text-xs font-black text-slate-800 mb-1">{m.location} • {m.error_type}</p>
                           <p className="text-[13px] text-slate-500 font-medium leading-snug">{m.description}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex items-center gap-3 p-4 bg-emerald-50 text-emerald-700 rounded-2xl">
                       <CheckCircle2 size={18} />
                       <p className="text-sm font-bold">Hech qanday xato topilmadi!</p>
                    </div>
                  )}
               </div>

               {/* Positives & Motivation */}
               <div className="space-y-6">
                  <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm space-y-6">
                    <h4 className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-slate-400">
                      <Sparkles size={14} className="text-emerald-500" /> Ijobiy Tomonlar
                    </h4>
                    <ul className="space-y-3">
                      {result.positive_points.map((p: string, i: number) => (
                        <li key={i} className="flex items-start gap-3 text-[13px] font-bold text-slate-600 leading-tight">
                           <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                           {p}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-emerald-50 p-6 rounded-[2rem] border border-emerald-100">
                     <p className="text-[13px] font-bold text-emerald-800 italic leading-relaxed text-center">
                       "{result.motivational_message}"
                     </p>
                  </div>
               </div>
            </div>
          </div>
        )}

        {error && (
          <div className="flex items-center gap-3 p-4 bg-red-50 text-red-600 rounded-2xl border border-red-100 animate-slide-up">
             <AlertCircle size={20} />
             <p className="text-sm font-bold">{error}</p>
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="flex justify-center gap-4 pt-6">
        {!result && !isAnalyzing ? (
          <button 
            onMouseDown={startRecording}
            onMouseUp={stopRecording}
            onTouchStart={startRecording}
            onTouchEnd={stopRecording}
            className={`flex items-center gap-3 px-12 py-5 rounded-[2.2rem] font-black uppercase tracking-widest transition-all shadow-xl active:scale-95 ${isRecording ? 'bg-red-500 text-white animate-pulse' : 'bg-slate-900 text-white hover:bg-emerald-600'}`}
          >
            <Mic size={20} />
            {isRecording ? 'Eshityapman...' : 'Yozish uchun bosing'}
          </button>
        ) : (
          <div className="flex gap-4">
            <button 
              onClick={resetTest}
              className="flex items-center gap-3 px-10 py-5 rounded-[2.2rem] bg-slate-100 text-slate-600 font-black uppercase tracking-widest hover:bg-slate-200 transition-all"
            >
              <RotateCcw size={20} /> Qayta urinish
            </button>
            {result?.is_perfect && (
              <button 
                className="flex items-center gap-3 px-10 py-5 rounded-[2.2rem] bg-emerald-600 text-white font-black uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-xl shadow-emerald-200"
              >
                Keyingi Oyat <ArrowRight size={20} />
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

// Placeholder icons missing from import
const Brain = ({ className, size }: { className?: string, size?: number }) => (
  <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96.44 2.5 2.5 0 0 1-2.96-3.08 3 3 0 0 1-.34-5.58 2.5 2.5 0 0 1 1.32-4.24 2.5 2.5 0 0 1 4.44-2.48z"/>
    <path d="M14.5 2A2.5 2.5 0 0 0 12 4.5v15a2.5 2.5 0 0 0 4.96.44 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.58 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-4.44-2.48z"/>
  </svg>
);

export default Testing;
