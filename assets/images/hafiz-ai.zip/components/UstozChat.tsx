import React, { useState } from 'react';
import { Send, User, Bot } from 'lucide-react';
import { Surah } from '../types';

interface UstozChatProps {
  surah: Surah | null;
  mode: string;
}

const UstozChat: React.FC<UstozChatProps> = () => {
  const [messages, setMessages] = useState([
    { role: 'assistant', text: "Assalomu alaykum! Men sizning sun'iy intellekt asosidagi tajvid ustozingizman. Bugun qaysi oyatda qiynalayapsiz?" }
  ]);
  const [input, setInput] = useState('');

  const handleSend = () => {
    if (!input.trim()) return;
    setMessages([...messages, { role: 'user', text: input }]);
    setInput('');
    setTimeout(() => {
      setMessages(prev => [...prev, { role: 'assistant', text: "Bu juda yaxshi savol! Ushbu oyatda 'G'unna' qoidasiga e'tibor berish kerak. Burningizda 2 harakat miqdorida ushlab turing." }]);
    }, 1000);
  };

  return (
    <div className="h-full flex flex-col p-6 max-w-4xl mx-auto">
      <div className="flex-1 overflow-y-auto space-y-6 pb-24">
        {messages.map((m, i) => (
          <div key={i} className={`flex gap-4 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
             <div className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 ${m.role === 'user' ? 'bg-slate-200 text-slate-500' : 'bg-emerald-100 text-emerald-600'}`}>
                {m.role === 'user' ? <User size={20} /> : <Bot size={20} />}
             </div>
             <div className={`p-4 rounded-3xl max-w-[80%] text-sm font-bold leading-relaxed ${m.role === 'user' ? 'bg-slate-900 text-white rounded-tr-none' : 'bg-white shadow-sm border border-slate-100 text-slate-700 rounded-tl-none'}`}>
                {m.text}
             </div>
          </div>
        ))}
      </div>

      <div className="fixed bottom-32 left-1/2 -translate-x-1/2 w-full max-w-2xl px-6">
        <div className="bg-white p-2 rounded-full shadow-2xl border border-slate-100 flex gap-2">
           <input 
             type="text" 
             value={input}
             onChange={(e) => setInput(e.target.value)}
             placeholder="Ustozdan savol so'rang..."
             className="flex-1 bg-transparent px-6 py-3 outline-none text-sm font-bold text-slate-700"
             onKeyPress={(e) => e.key === 'Enter' && handleSend()}
           />
           <button 
             onClick={handleSend}
             className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center text-white shadow-lg hover:bg-emerald-700 transition-all"
           >
             <Send size={18} />
           </button>
        </div>
      </div>
    </div>
  );
};

export default UstozChat;