import { TAJWID_MAP } from "./tajweedMap";

/**
 * Matnni tajvid qoidalariga ko'ra rangli HTML-ga o'giradi.
 * API-dan keladigan <tajweed> teglarini <span> ga aylantiradi.
 */
export function parseTajweed(text: string): string {
  if (!text) return "";

  let processed = text
    .replace(/<tajweed/g, '<span')
    .replace(/<\/tajweed>/g, '</span>');

  let result = "";
  let i = 0;

  while (i < processed.length) {
    if (processed[i] === "<") {
      let tag = "";
      while (i < processed.length && processed[i] !== ">") {
        tag += processed[i++];
      }
      if (i < processed.length) tag += processed[i++];
      result += tag;
      continue;
    }

    if (processed[i] === "[" && i + 1 < processed.length) {
      let j = i + 1;
      let code = "";
      while (j < processed.length && processed[j] !== ":" && processed[j] !== "]") {
        code += processed[j++];
      }
      
      const rule = TAJWID_MAP[code];
      if (rule) {
        if (processed[j] === ":") {
          j++;
          while (j < processed.length && /\d/.test(processed[j])) j++;
        }
        if (processed[j] === "]") j++;

        let content = "";
        let depth = 1;
        let k = j;
        while (k < processed.length && depth > 0) {
          if (processed[k] === "[") depth++;
          else if (processed[k] === "]") depth--;
          if (depth > 0) content += processed[k++];
          else k++;
        }
        result += `<span class="${rule.class}">${parseTajweed(content)}</span>`;
        i = k;
      } else {
        result += processed[i++];
      }
    } else {
      result += processed[i++];
    }
  }

  return result;
}

/**
 * So'zlarga bo'lishda tajvid teglarini inobatga oladi.
 */
export function splitTajweedToWords(encodedText: string): string[] {
  if (!encodedText) return [];
  
  const rawWords: string[] = [];
  let currentWord = "";
  let depth = 0;
  let inHtmlTag = false;

  for (let i = 0; i < encodedText.length; i++) {
    const char = encodedText[i];
    
    if (char === "<") inHtmlTag = true;
    if (char === ">") inHtmlTag = false;

    if (!inHtmlTag) {
      if (char === "[") depth++;
      else if (char === "]") depth--;
    }

    if (char === " " && depth === 0 && !inHtmlTag) {
      if (currentWord.trim()) rawWords.push(currentWord);
      currentWord = "";
    } else {
      currentWord += char;
    }
  }
  if (currentWord.trim()) rawWords.push(currentWord);
  
  return rawWords;
}

/**
 * Berilgan bo'lak oyat raqami ekanligini aniqlash.
 * Raqamlar, maxsus klasslar va arabcha end-of-ayah belgilarini tekshiradi.
 */
export function isAyahMarker(word: string): boolean {
  if (!word) return false;
  const cleanWord = word.replace(/<[^>]*>/g, '').trim();
  // 1. Agar faqat raqam bo'lsa (Lotin yoki Arab raqamlari)
  const isNumeric = /^[0-9\u0660-\u0669]+$/.test(cleanWord);
  // 2. Maxsus klasslar yoki Unicode belgilari
  const hasMarkerClass = word.includes('class="end"') || word.includes('class="ayah-number"');
  const hasUnicodeMarker = /[\u06DD\u06DE]/.test(word);
  
  return isNumeric || hasMarkerClass || hasUnicodeMarker;
}
