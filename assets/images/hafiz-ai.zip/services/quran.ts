import { Surah, Ayah } from '../types';

const FOUNDATION_API = 'https://api.quran.com/api/v4';
const CLOUD_API = 'https://api.alquran.cloud/v1';
const DEFAULT_TRANSLATION_ID = 101; // Sodik Muhammad (Uzbek)

export const RECITERS = [
  { id: 7, cloudId: 'ar.alafasy', name: 'Mishary Alafasy', style: 'Murattal' },
  { id: 6, cloudId: 'ar.husary', name: 'Khalil Al-Husary', style: 'Tajweed' },
  { id: 1, cloudId: 'ar.abdulsamad', name: 'AbdulBaset Mujawwad', style: 'Mujawwad' },
  { id: 3, cloudId: 'ar.abdurrahmansudais', name: 'Abdurrahman Sudais', style: 'Murattal' }
];

// Enhanced Cache System
const cache = {
  surahs: null as Surah[] | null,
  // Matnlar sura raqami bo'yicha keshlanadi (qoriga bog'liq emas)
  surahText: {} as Record<number, any[]>,
  // Audio URL-lar sura va qori kombinatsiyasi bo'yicha keshlanadi
  surahAudio: {} as Record<string, Record<number, string>>
};

const cleanTranslation = (text: string): string => {
  if (!text) return "";
  return text
    .replace(/<sup[^>]*>.*?<\/sup>/g, '') 
    .replace(/\[\d+\]/g, '') 
    .replace(/<[^>]*>/g, '')
    .replace(/&nbsp;/g, ' ')
    .trim();
};

const formatAudioUrl = (url: string | null): string | null => {
  if (!url) return null;
  if (url.startsWith('http')) return url;
  const path = url.startsWith('/') ? url.slice(1) : url;
  return `https://verses.quran.com/${path}`;
};

export const quranApi = {
  getSurahs: async (): Promise<Surah[]> => {
    if (cache.surahs) return cache.surahs;
    try {
      const res = await fetch(`${FOUNDATION_API}/chapters?language=uz`);
      const data = await res.json();
      const surahs = data.chapters.map((s: any) => ({
        number: s.id,
        name: s.name_arabic,
        englishName: s.name_simple,
        englishNameTranslation: s.translated_name?.name || s.name_simple,
        numberOfAyahs: s.verses_count,
        revelationType: s.revelation_place,
      }));
      cache.surahs = surahs;
      return surahs;
    } catch (e) {
      const res = await fetch(`${CLOUD_API}/surah`);
      const data = await res.json();
      const surahs = data.data.map((s: any) => ({
        number: s.number,
        name: s.name,
        englishName: s.englishName,
        englishNameTranslation: s.englishNameTranslation,
        numberOfAyahs: s.numberOfAyahs,
        revelationType: s.revelationType,
      }));
      cache.surahs = surahs;
      return surahs;
    }
  },

  getSurahData: async (chapterId: number, reciterId: number = 7): Promise<any[]> => {
    const audioKey = `${chapterId}_${reciterId}`;
    
    // Agar matn ham, ushbu qori audiosi ham keshda bo'lsa, birlashtirib qaytaramiz
    if (cache.surahText[chapterId] && cache.surahAudio[audioKey]) {
      return cache.surahText[chapterId].map(v => ({
        ...v,
        audioUrl: cache.surahAudio[audioKey][v.numberInSurah]
      }));
    }

    try {
      const url = `${FOUNDATION_API}/verses/by_chapter/${chapterId}?per_page=300&words=true&fields=text_uthmani_tajweed,text_uthmani&word_fields=text_uthmani&translations=${DEFAULT_TRANSLATION_ID}&audio=${reciterId}`;
      const res = await fetch(url);
      const data = await res.json();
      
      if (!data.verses) throw new Error("No data");

      const audioMap: Record<number, string> = {};
      const verses = data.verses.map((v: any) => {
        const audioUrl = formatAudioUrl(v.audio?.url) || "";
        audioMap[v.verse_number] = audioUrl;
        
        return {
          number: v.id,
          source: 'foundation',
          text: v.text_uthmani_tajweed || v.text_uthmani || "",
          numberInSurah: v.verse_number,
          translation: cleanTranslation(v.translations?.[0]?.text || ""),
          ayahKey: v.verse_key,
          audioUrl: audioUrl,
          words: (v.words || []).map((w: any) => ({
            id: w.id,
            text: w.text_uthmani || w.text || "", 
            position: w.position
          }))
        };
      });

      // Keshni yangilaymiz
      if (!cache.surahText[chapterId]) {
        cache.surahText[chapterId] = verses.map(({ audioUrl, ...rest }) => rest);
      }
      cache.surahAudio[audioKey] = audioMap;

      return verses;
    } catch (e) {
      // Fallback to Cloud API
      const reciter = RECITERS.find(r => r.id === reciterId);
      const res = await fetch(`${CLOUD_API}/surah/${chapterId}/editions/quran-tajweed,uz.sodik,${reciter?.cloudId || 'ar.alafasy'}`);
      const data = await res.json();
      
      const audioMap: Record<number, string> = {};
      const verses = data.data[0].ayahs.map((v: any, i: number) => {
        const audioUrl = data.data[2].ayahs[i].audio;
        audioMap[v.numberInSurah] = audioUrl;
        
        return {
          number: v.number,
          source: 'cloud',
          text: v.text, 
          numberInSurah: v.numberInSurah,
          translation: data.data[1].ayahs[i].text,
          ayahKey: `${chapterId}:${v.numberInSurah}`,
          audioUrl: audioUrl,
          words: []
        };
      });

      if (!cache.surahText[chapterId]) {
        cache.surahText[chapterId] = verses.map(({ audioUrl, ...rest }) => rest);
      }
      cache.surahAudio[audioKey] = audioMap;

      return verses;
    }
  }
};