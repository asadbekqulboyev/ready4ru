import { User, HifzProgress } from '../types';

const STORAGE_KEYS = {
  USER: 'hafiz_ai_user',
  PROGRESS: 'hafiz_ai_progress',
  LAST_READ_PAGE: 'hafiz_ai_last_page'
};

export const db = {
  getUser: (): User | null => {
    const data = localStorage.getItem(STORAGE_KEYS.USER);
    return data ? JSON.parse(data) : null;
  },
  
  saveUser: (user: User) => {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
  },

  getProgress: (): HifzProgress[] => {
    const data = localStorage.getItem(STORAGE_KEYS.PROGRESS);
    return data ? JSON.parse(data) : [];
  },

  updateProgress: (newProgress: HifzProgress) => {
    const current = db.getProgress();
    const index = current.findIndex(p => 
      p.surahNumber === newProgress.surahNumber && p.ayahNumber === newProgress.ayahNumber
    );
    
    if (index > -1) {
      current[index] = newProgress;
    } else {
      current.push(newProgress);
    }
    
    localStorage.setItem(STORAGE_KEYS.PROGRESS, JSON.stringify(current));
  },

  getLastReadPage: (): number => {
    const page = localStorage.getItem(STORAGE_KEYS.LAST_READ_PAGE);
    return page ? parseInt(page) : 1;
  },

  saveLastReadPage: (page: number) => {
    localStorage.setItem(STORAGE_KEYS.LAST_READ_PAGE, page.toString());
  }
};