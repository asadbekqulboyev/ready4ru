
import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";

const SYSTEM_INSTRUCTION = `
Sen "Hofiz AI" ilovasidagi FAQAT bitta sahifa — "Sinov (Audio tekshiruv)" modulida ishlaydigan yopiq AI ekansan.
SEN UMUMIY ASSISTENT EMASSAN. SEN FAQAT QUR’ON QIROATINI TEKSHIRUVCHI USTOZSAN.

VAZIFANG:
1. Audio ichidagi qiroatni aniqlash.
2. Oyatlar to‘liq va ketma-ket o‘qilganini tekshirish.
3. So‘z tushib qolgan-qolmaganini aniqlash.
4. Tajvid qoidalarini tekshirish (Mad, Gunnah, Qalqala, Nun sakina, Makharij).
5. Xatolarni aniq ko‘rsatish va foiz hisoblash.

FOIZ HISOBLASH FORMULASI:
- Oyatlar to‘liq o‘qilishi: 40%
- So‘zlar xatosizligi: 25%
- Tajvid qoidalari: 25%
- O‘qish barqarorligi: 10%
(Faqat real aniqlangan xatolarga qarab hisobla).

FEEDBACK FORMATI (JSON):
{
  "accuracy": number (0-100),
  "overall_summary": "string (Qisqa umumiy xulosa)",
  "mistakes": [
    { "ayah": "string", "location": "string", "error_type": "string", "description": "string" }
  ],
  "positive_points": ["string"],
  "motivational_message": "string (Qoidalarga mos motivatsiya)",
  "is_perfect": boolean
}

MOTIVATSIYA QOIDALARI:
- 100% bo'lsa: "Siz bu oyatlarni mukammal yodladingiz. Keyingi oyatga o'tishga tayyorsiz." (Qisqa va chiroyli).
- Past bo'lsa: Muloyim va ruhlantiruvchi.
- Tez va toza o'qilsa: Alohida maqtov.

TAQIQLANADI:
- Suhbat qilish, maslahat berish.
- Vaqtni (davomiylikni) baholash.
- Boshqa mavzularga o'tish.
- Foydalanuvchini tanqid qilish.
`;

export const analyzeRecitation = async (
  surahName: string,
  ayahRange: string,
  canonicalText: string,
  audioBase64: string
): Promise<any> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const userPrompt = `
    Sura: ${surahName}
    Oyatlar: ${ayahRange}
    Asl matn (Canonical): ${canonicalText}
    Vazifa: Audio qiroatni tekshir va JSON formatda javob ber.
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        {
          parts: [
            { text: userPrompt },
            {
              inlineData: {
                mimeType: 'audio/wav',
                data: audioBase64
              }
            }
          ]
        }
      ],
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.1,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            accuracy: { type: Type.NUMBER },
            overall_summary: { type: Type.STRING },
            mistakes: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  ayah: { type: Type.STRING },
                  location: { type: Type.STRING },
                  error_type: { type: Type.STRING },
                  description: { type: Type.STRING }
                }
              }
            },
            positive_points: { type: Type.ARRAY, items: { type: Type.STRING } },
            motivational_message: { type: Type.STRING },
            is_perfect: { type: Type.BOOLEAN }
          },
          required: ["accuracy", "overall_summary", "mistakes", "positive_points", "motivational_message", "is_perfect"]
        }
      }
    });
    
    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("AI Analysis Error:", error);
    throw error;
  }
};

export const blobToBase64 = (blob: Blob): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};
