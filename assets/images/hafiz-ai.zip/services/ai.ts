
import { GoogleGenAI, Type } from "@google/genai";

export const aiService = {
  checkRecitationStrict: async (targetText: string, transcript: string) => {
    // Create new instance right before making an API call as per guidelines
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    
    const prompt = `
      Siz qattiqqo'l va professional Tajvid ustozisiz. 
      Vazifa: Talabaning Qur'on qiroatini (transkriptini) asl matn bilan solishtiring.
      
      Asl matn (mustahkam yodlanishi kerak): "${targetText}"
      Talabaning transkripti: "${transcript}"
      
      Qoidalar:
      1. Agar o'xshashlik 95% dan past bo'lsa, "isPassed" false bo'lsin.
      2. Faqat so'zlarning to'g'riligiga e'tibor bering. 
      3. O'zbek tilida javob bering.

      Javob faqat JSON formatida bo'lsin:
      {
        "accuracy": number (0-100),
        "isPassed": boolean,
        "feedback": "Aniq va professional tavsiya",
        "mistakes": ["aniq xatoliklar ro'yxati"]
      }
    `;

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: { parts: [{ text: prompt }] },
        config: {
          responseMimeType: "application/json",
          // Using responseSchema for robust JSON structure as recommended
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              accuracy: {
                type: Type.NUMBER,
                description: "Accuracy of the recitation from 0 to 100",
              },
              isPassed: {
                type: Type.BOOLEAN,
                description: "Whether the recitation meets the 95% accuracy threshold",
              },
              feedback: {
                type: Type.STRING,
                description: "Professional feedback in Uzbek",
              },
              mistakes: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "List of specific mistakes found",
              },
            },
            required: ["accuracy", "isPassed", "feedback", "mistakes"],
          },
        }
      });

      // Use .text property directly as per guidelines
      const responseText = response.text || '{}';
      return JSON.parse(responseText);
    } catch (e) {
      console.error("AI Service Error:", e);
      return { 
        accuracy: 0, 
        isPassed: false, 
        feedback: "Tizimda xatolik yuz berdi. Iltimos qaytadan urinib ko'ring.", 
        mistakes: ["API ulanish xatosi"] 
      };
    }
  }
};
